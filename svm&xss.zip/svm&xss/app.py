from flask import Flask, request, render_template
import joblib
import re

app = Flask(__name__)

# 加载训练好的模型
clf = joblib.load("train_model.pkl")

def get_len(url):
    return len(url)

def get_url_count(url):
    if re.search('(http://)|(https://)', url, re.IGNORECASE):
        return 1
    else:
        return 0

def get_evil_char(url):
    return len(re.findall("[<>,\'\"/]", url, re.IGNORECASE))

def get_evil_word(url):
    return len(
        re.findall("(alert)|(script=)(%3c)|(%3e)|(%20)|(onerror)|(onload)|(eval)|(src=)|(prompt)", url, re.IGNORECASE))

def classify_single_sample(sample):
    sample_features = [get_len(sample), get_url_count(sample), get_evil_char(sample), get_evil_word(sample)]
    predicted_label = clf.predict([sample_features])
    if predicted_label == 1:
        return "It's XSS"
    else:
        return "It's not XSS"

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/detect', methods=['POST'])
def detect_xss():
    payload = request.form.get('payload')
    classification = classify_single_sample(payload)
    return render_template('result.html', result=classification)

if __name__ == '__main__':
    app.run()
