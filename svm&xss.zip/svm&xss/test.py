import re
import numpy as np
# from sklearn import cross_validation
from sklearn import datasets
from sklearn import model_selection
from sklearn import svm
# from sklearn.externals import joblib
from sklearn.metrics import classification_report
from sklearn import metrics
import joblib
import matplotlib.pyplot as plt


x = []
y = []


def get_len(url):
    return len(url)


def get_url_count(url):
    if re.search('(http://)|(https://)', url, re.IGNORECASE):
        return 1
    else:
        return 0


def get_evil_char(url):
    return len(re.findall("[<>,\'\"/]", url, re.IGNORECASE))


def get_evil_word(url):
    return len(
        re.findall("(alert)|(script=)(%3c)|(%3e)|(%20)|(onerror)|(onload)|(eval)|(src=)|(prompt)", url, re.IGNORECASE))


def do_metrics(y_test, y_pred):
    print("metrics.accuracy_score:")
    print(metrics.accuracy_score(y_test, y_pred))
    print("metrics.confusion_matrix:")
    print(metrics.confusion_matrix(y_test, y_pred))
    print("metrics.precision_score:")
    print(metrics.precision_score(y_test, y_pred))
    print("metrics.recall_score:")
    print(metrics.recall_score(y_test, y_pred))
    print("metrics.f1_score:")
    print(metrics.f1_score(y_test, y_pred))


def etl(filename, data, isxss):
    with open(filename,encoding='UTF-8') as f:
        for line in f:
            f1 = get_len(line)
            f2 = get_url_count(line)
            f3 = get_evil_char(line)
            f4 = get_evil_word(line)
            data.append([f1, f2, f3, f4])
            if isxss:
                y.append(1)
            else:
                y.append(0)
    return data


etl('xss-200000.txt', x, 1)
etl('good-xss-200000.txt', x, 0)

x_train, x_test, y_train, y_test = model_selection.train_test_split(x, y, test_size=0.4, random_state=0)

clf = svm.SVC(kernel='linear', C=1).fit(x_train, y_train)

y_pred = clf.predict(x_test)
do_metrics(y_test, y_pred)

# 绘制训练数据集
x_train_arr = np.array(x_train)
plt.scatter(x_train_arr[:, 0], x_train_arr[:, 1], c=y_train, cmap=plt.cm.Paired)
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.title('Training Data')
plt.show()

# 绘制测试数据集
x_test_arr = np.array(x_test)
plt.scatter(x_test_arr[:, 0], x_test_arr[:, 1], c=y_test, cmap=plt.cm.Paired)
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.title('Testing Data')
plt.show()


joblib.dump(clf,"train_model.pkl")



def classify_single_sample(sample):
    # 提取样本特征
    sample_features = [get_len(sample), get_url_count(sample), get_evil_char(sample), get_evil_word(sample)]
    # 使用分类器进行预测
    predicted_label = clf.predict([sample_features])
    if predicted_label == 1:
        return "It's XSS"
    else:
        return "It's not XSS"



#单个样例输入
sample_url = input("请输入需要测试的样例：")

classification = classify_single_sample(sample_url)
print("分类结果:", classification)



